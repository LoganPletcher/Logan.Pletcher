README.txt file

How to access and use the program:
- Unzip the folder.
- Run the program.
- Choose whether to make a Mystery or Treasure Card.
- Input all the information you want to input.
- Save the file by naming the file.
- Choose whether or not to make another card.

How to use loading:
- You can load xml objects during the Mystery Card creation screen
	and the Treasure Card creation screen.
- You should only load a Mystery Card xml file during the Mystery Card creation screen and 
	only load a Treasure Card xml file during the Treasure Card creation screen.
- If you load something into the Treasure Card creation screen that is not a Treasure Card,
	the program will throw an error at you, but it wil not crash the program.
- Same thing for loading into the Mystery Card creation screen with something other than
	a Mystery Card.

Extra info:
- Do not mess with the Empty Folder or the file inside the Empty Folder.